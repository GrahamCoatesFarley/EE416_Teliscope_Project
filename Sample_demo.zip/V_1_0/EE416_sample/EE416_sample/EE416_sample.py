from Functions import *                                                 # Imports functions from project function files 

serial = Setup_Uart_port()                                              # Sets up communication port

(H_Angle, V_Angle) = Get_User_angles()                                  # gets two angles from user

std_vect_len = 12                                                       # Number of bits in standard logic vector 
V_data = angle_to_Motor_data(V_Angle, 2**std_vect_len-1, 0, 90)         # Calculates what the vertical motor data will be
H_data = angle_to_Motor_data(H_Angle, 2**std_vect_len-1, 0, 360)        # Calculates what the horizontal motor data will be

print("Vertical Data: " + str(V_data))                                  # Prints V_data 
print("Horizontial Data: " + str(H_data))                               # Prints V_data 

Uart_Tx(serial, H_data, V_data)                                         # sends data through Uart
Close_Uart(serial)                                                      # Closes Uart communication port

print("Program Complete")                                               # Completion message 